const e=t=>new Date(t).toLocaleDateString().split("/").join("-");export{e as f};
